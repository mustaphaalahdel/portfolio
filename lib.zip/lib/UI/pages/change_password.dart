import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xfffafafa),
        elevation: 0,
        title: Text(""),
        leading: IconButton(
          onPressed: () async {
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back_outlined,
            color: Colors.grey[800],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Change password",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8),
            Text("Enter your new password and confirm your password"),
            SizedBox(height: 33),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.only(start: 12),
                    child: Text("New password"),
                  ),
                  SizedBox(height: 6),
                  TextFormField(
                    decoration: InputDecoration(
                      hintText: "enter new password ..."
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 22),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.only(start: 12),
                    child: Text("Confirm password"),
                  ),
                  SizedBox(height: 6),
                  TextFormField(
                    decoration: InputDecoration(
                        hintText: "enter confirm password ..."
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 33),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              width: Get.width,
              height: 60,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: StadiumBorder(),
                ),
                onPressed: () async {

                },
                child: Text("Apply"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

