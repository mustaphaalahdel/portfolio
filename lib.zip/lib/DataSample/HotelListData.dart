class hotelListData {
  String? img, name, location, price, id;
  double? rating;

  hotelListData(
      {this.img, this.id, this.name, this.location, this.price, this.rating});
}

List<hotelListData> hotelDataDummy = [
  hotelListData(
      id: "dsadsa",
      img: "assets/image/hotel/hotel1.jpg",
      name: "Lux Hotel Toronto",
      price: "140",
      location: "Toronto Canada",
      rating: 4.4),
  hotelListData(
      id: "fds32",
      img: "assets/image/hotel/hotel2.jpg",
      name: "Grand Hotel Start",
      price: "210",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "cxve2",
      img: "assets/image/hotel/hotel3.jpg",
      name: "Salad Hotel Start",
      price: "130",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "fdfg34",
      img: "assets/image/room/room1.jpg",
      name: "Room Motel Toronto",
      price: "50",
      location: "Toronto Canada",
      rating: 4.4),
  hotelListData(
      id: "vfsxa",
      img: "assets/image/room/room2.jpg",
      name: "Grand Hotel Start",
      price: "260",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "zsdqwe",
      img: "assets/image/room/room3.jpg",
      name: "Alexis Hotel",
      price: "150",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "cxzsd2",
      img: "assets/image/room/room4.jpg",
      name: "Traveloka Hotel Toronto",
      price: "200",
      location: "Toronto Canada",
      rating: 4.4),
  hotelListData(
      id: "fdswqe2",
      img: "assets/image/room/room5.jpg",
      name: "Polksi Hotel Start",
      price: "230",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "dsaxz23",
      img: "assets/image/room/room6.jpg",
      name: "Loaks Hotel",
      price: "20",
      location: "Sillicon Valley",
      rating: 3.9),
  hotelListData(
      id: "dsaxz2sda3",
      img: "assets/image/room/room6.jpg",
      name: "Loaks Hotel",
      price: "30",
      location: "Sillicon Valley",
      rating: 3.9),
];
