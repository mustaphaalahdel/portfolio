class savedItem{
  String? img,title,price;
  int? id;
  savedItem({
    this.id,
   this.img,
    this.title,
    this.price,
});
}