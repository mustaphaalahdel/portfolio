class messageItem{
  String? img,name,title,message;
  int? id;
  messageItem({
    this.id,
   this.img,
    this.title,
    this.name,
    this.message,
});
}