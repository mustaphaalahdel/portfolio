
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';

Future getFCMToken() async {
  try {
    FirebaseMessaging.instance.getToken().then((value) {
      print("============================= token ============================");
      print("${value}");
      print("============================= token ============================");
      print("FirebaseMessaging.onMessage.listen(onArriveForegroundfbm)");
    }).catchError((err) {
      print("err get token fbm: ${err}");
      Fluttertoast.showToast(
          msg: "لا يمكنك تلقي الاشعارات تحقق من اتصال الانترنت");
    });
  }catch(err){
    print("err messaging: ${err}");
  }

}

Future<String> getExternalStorage() async {
  Directory? dir = await getExternalStorageDirectory();
  return dir!.path;
}
